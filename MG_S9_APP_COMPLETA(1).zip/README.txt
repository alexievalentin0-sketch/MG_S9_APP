MG S9 APP – versiune completă pentru GitHub Pages

Fișiere: index.html și manifest.webmanifest.
Pentru actualizarea site-ului existent, încarcă AMBELE fișiere în rădăcina repository-ului MG_S9_APP și confirmă înlocuirea index.html. Păstrează adresa GitHub Pages existentă.

Funcții: evidență consum electric, costuri, kilometraj, alimentări, grafice, raport PDF, export/import backup, RCA, rovinietă, ITP, revizie, istoric întreținere, daune/accidente cu fotografie, PRO FM, căutare YouTube și Google Maps.

Important: datele sunt stocate local în browserul/telefonul în care folosești aplicația. Folosește periodic Descarcă backup. Redarea automată PRO FM este încercată la deschidere, dar Chrome/Android poate cere o atingere pentru pornirea sunetului.
